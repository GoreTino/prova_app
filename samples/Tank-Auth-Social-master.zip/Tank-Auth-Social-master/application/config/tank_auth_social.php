<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Facebook App ID
|
| If you want to integrate with Facebook Connect authentication, put your
| Facebook App ID below.
|--------------------------------------------------------------------------
*/
$config['facebook_connect'] 	= TRUE;
$config['facebook_app_id'] 		= '';
$config['facebook_app_secret'] 	= '';
$config['facebook_user_email']	= TRUE;
$config['facebook_offline']		= TRUE;
$config['facebook_scope']		= ''; //separate by commas

/* End of file tank_auth_social.php */
/* Location: ./application/config/tank_auth_social.php */
