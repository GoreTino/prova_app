<form action="/index.php/topic/upload_receive" method="POST" enctype="multipart/form-data">
	<input type="file" name="user_upload_file" />
	<input type="submit" />
</form>