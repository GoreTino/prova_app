<?php
class Module extends CI_controller {
	public function get($id){
		echo $id;
	}
}
?>