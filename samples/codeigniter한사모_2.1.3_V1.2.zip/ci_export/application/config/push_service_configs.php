<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| PUSH SERVICE FOR MOBILE APP
| -------------------------------------------------------------------------
|
|
|
*/
$config['GOOGLE_API_KEY'] = '';