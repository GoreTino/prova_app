<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="CodeIgniter 한국사용자포럼"/>
<meta name="keywords" content="CodeIgniter, 한국사용자포럼"/>
<meta name="author" content="author"/>
<link rel="stylesheet" type="text/css" href="<?php echo CSS_DIR?>/default.css" media="screen"/>
<link href="<?php echo CSS_DIR?>/jquery-ui-1.7.1.custom.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo JS_DIR?>/common.js"></script>
<script type="text/javascript" src="<?php echo JS_DIR?>/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="<?php echo JS_DIR?>/jquery-ui-1.7.1.custom.min.js"></script>
<script type="text/javascript" src="<?php echo JS_DIR?>/jquery.framedialog.js"></script>
<script type="text/javascript" src="<?php echo JS_DIR?>/jquery.jScale.js"></script>
<title>CodeIgniter 한국사용자포럼</title>
</head>

<body>
<div class="content0">