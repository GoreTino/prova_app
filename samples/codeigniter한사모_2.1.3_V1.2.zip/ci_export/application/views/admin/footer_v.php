</div>
<!-- footer 영역 -->
<div id="footer">
<table width="100%">
<tr>
<td align="center">
<h5>Copyright (c) 2009. <span class="cname"><a mailto="webmaster@codeigniter-kr.org">CodeIgniter 한국사용자포럼</a></span> All rights reserved.</h5></td>
</tr>
</table>
</div>
<!--// footer 영역 -->
</div>

</body>
</html>