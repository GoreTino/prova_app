<table width="100%" height="25" border=0 style="background:#D9D7D7; margin-bottom:15px;">
<tr align="center">
<td><a href="/admin/main">회원관리</a></td>
<td><a href="/admin/main/board">게시판관리</a></td>
<td><a href="http://codeigniter-kr.org/Myadmin/" target="_new">DB관리</a></td>
</tr>
</table>